package com.ryn.xintermarket.data

import android.content.Context
import com.ryn.xintermarket.BuildConfig
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.TimeZone

enum class Horizon(val key: String, val label: String) {
    TODAY("today", "Today"), WEEK("week", "This week"), MONTH("month", "This month")
}

/** Semua field boleh null. Null = DATA UNAVAILABLE, tidak pernah diisi tebakan. */
data class Macro(
    val dxyChgPct: Double?, val us10yChgBp: Double?, val realYieldChgBp: Double?,
    val fedRate: Double?, val fedCut: Double?, val fedHold: Double?, val fedHike: Double?,
    val nextFomc: String?, val prevFomc: String?,
    val inflTrendPp: Double?, val unempChgPp: Double?, val vixChgPct: Double?,
    val goldPrice: Double?, val nfpSignals: List<Double>?,
    val updated: String?, val source: String?
)

sealed interface MacroState {
    data object Loading : MacroState
    data class Unavailable(val reason: String) : MacroState
    data class Ready(val data: Map<Horizon, Macro>, val cached: Boolean) : MacroState
}

data class HistRec(
    val date: String, val forecast: String?, val previous: String?, val actual: String?,
    val usd: String?, val gold: String?, val yld: String?
)

private fun JSONObject.d(k: String): Double? =
    if (!has(k) || isNull(k)) null else optDouble(k, Double.NaN).takeIf { !it.isNaN() }

private fun JSONObject.s(k: String): String? =
    if (!has(k) || isNull(k)) null else optString(k).ifBlank { null }

object Http {
    fun get(path: String): String? {
        val base = BuildConfig.API_BASE_URL.trim().trimEnd('/')
        if (base.isEmpty()) return null
        val c = URL(base + path).openConnection() as HttpURLConnection
        c.connectTimeout = 10000; c.readTimeout = 15000
        if (c.responseCode != 200) throw RuntimeException("HTTP ${c.responseCode}")
        return c.inputStream.bufferedReader().readText()
    }
}

object Fmt {
    fun ny(iso: String?, local: Boolean = false): String {
        if (iso == null) return "DATA UNAVAILABLE"
        return try {
            val p = SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss'Z'", Locale.US)
                .apply { timeZone = TimeZone.getTimeZone("UTC") }.parse(iso)!!
            val o = SimpleDateFormat(if (local) "yyyy-MM-dd HH:mm z" else "yyyy-MM-dd HH:mm 'ET'", Locale.US)
            if (!local) o.timeZone = TimeZone.getTimeZone("America/New_York")
            o.format(p)
        } catch (e: Exception) { iso }
    }
    fun todayNy(): String = SimpleDateFormat("yyyy-MM-dd", Locale.US)
        .apply { timeZone = TimeZone.getTimeZone("America/New_York") }.format(Date())
    fun pct(x: Double) = String.format(Locale.US, "%.0f%%", x * 100)
    fun n1(x: Double) = String.format(Locale.US, "%+.1f", x)
}

object MacroRepository {
    private fun parse(raw: String): Map<Horizon, Macro> {
        val root = JSONObject(raw)
        val out = mutableMapOf<Horizon, Macro>()
        for (h in Horizon.values()) {
            val o = root.optJSONObject(h.key) ?: continue
            val sig = o.optJSONArray("nfp_leading_signals")?.let { a -> (0 until a.length()).map { a.getDouble(it) } }
            out[h] = Macro(
                o.d("dxy_chg_pct"), o.d("us10y_chg_bp"), o.d("real_yield_chg_bp"),
                o.d("fed_rate"), o.d("fed_cut_prob"), o.d("fed_hold_prob"), o.d("fed_hike_prob"),
                o.s("next_fomc"), o.s("prev_fomc"),
                o.d("inflation_trend_pp"), o.d("unemployment_chg_pp"), o.d("vix_chg_pct"),
                o.d("gold_price"), sig, o.s("last_updated") ?: root.s("last_updated"), o.s("source") ?: root.s("source")
            )
        }
        return out
    }

    suspend fun load(ctx: Context): MacroState = withContext(Dispatchers.IO) {
        val prefs = ctx.getSharedPreferences("cache", 0)
        try {
            val raw = Http.get("/macro") ?: return@withContext MacroState.Unavailable(
                "Backend belum dihubungkan. Isi API_BASE_URL di app/build.gradle.kts."
            )
            val data = parse(raw)
            if (data.isEmpty()) return@withContext MacroState.Unavailable("Server tidak mengirim data makro.")
            prefs.edit().putString("macro", raw).apply()
            MacroState.Ready(data, false)
        } catch (e: Exception) {
            val old = prefs.getString("macro", null)
            val data = try { old?.let { parse(it) } } catch (x: Exception) { null }
            if (!data.isNullOrEmpty()) MacroState.Ready(data, true)
            else MacroState.Unavailable("Gagal mengambil data: ${e.javaClass.simpleName}.")
        }
    }
}

object HistoryRepository {
    suspend fun load(series: String): List<HistRec>? = withContext(Dispatchers.IO) {
        try {
            val raw = Http.get("/history?series=$series") ?: return@withContext null
            val a = JSONArray(raw)
            (0 until a.length()).map { a.getJSONObject(it) }.map {
                HistRec(it.s("date") ?: "?", it.s("forecast"), it.s("previous"), it.s("actual"),
                    it.s("usd_reaction"), it.s("gold_reaction"), it.s("yield_reaction"))
            }
        } catch (e: Exception) { null }
    }
}
