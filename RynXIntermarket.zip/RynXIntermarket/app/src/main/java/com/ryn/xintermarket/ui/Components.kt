package com.ryn.xintermarket.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import com.ryn.xintermarket.engine.Bias

object Status {
    var lastCheck by mutableStateOf("-")
}

@Composable
fun Panel(title: String, content: @Composable ColumnScope.() -> Unit) {
    Column(
        Modifier.fillMaxWidth()
            .background(C.Panel, RoundedCornerShape(8.dp))
            .border(1.dp, C.Line, RoundedCornerShape(8.dp))
            .padding(14.dp)
    ) {
        Text(title, style = T.Label)
        Spacer(Modifier.height(8.dp))
        content()
    }
}

@Composable
fun KV(k: String, v: String, color: Color = C.Text) {
    Row(Modifier.fillMaxWidth().padding(vertical = 2.dp), horizontalArrangement = Arrangement.SpaceBetween) {
        Text(k, style = T.Label, modifier = Modifier.weight(1f))
        Text(v, style = T.Label.copy(color = color))
    }
}

@Composable
fun Chips(options: List<String>, selected: Int, onSel: (Int) -> Unit) {
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        options.forEachIndexed { i, o ->
            Box(
                Modifier.border(1.dp, if (i == selected) C.Gold else C.Line, RoundedCornerShape(6.dp))
                    .clickable { onSel(i) }.padding(horizontal = 10.dp, vertical = 6.dp),
                contentAlignment = Alignment.Center
            ) { Text(o, style = T.Label.copy(color = if (i == selected) C.Gold else C.Dim)) }
        }
    }
}

@Composable
fun Unavail(reason: String, onRetry: () -> Unit) {
    Panel("Status") {
        Text("DATA UNAVAILABLE", style = T.Body.copy(color = C.Down))
        Spacer(Modifier.height(6.dp))
        Text(reason, style = T.Label)
        Spacer(Modifier.height(10.dp))
        Text("Retry", style = T.Body.copy(color = C.Gold), modifier = Modifier.clickable { onRetry() }.padding(vertical = 6.dp))
        Text("Last check: ${Status.lastCheck}", style = T.Label)
    }
}

@Composable
fun ProbBar(label: String, v: Float, color: Color) {
    Row(Modifier.fillMaxWidth().padding(vertical = 3.dp), verticalAlignment = Alignment.CenterVertically) {
        Text(label, style = T.Label, modifier = Modifier.width(62.dp))
        Box(Modifier.weight(1f).height(6.dp).background(C.Line)) {
            Box(Modifier.fillMaxWidth(v.coerceIn(0f, 1f)).fillMaxHeight().background(color))
        }
        Text("  ${(v * 100).toInt()}%", style = T.Body)
    }
}

fun biasColor(b: Bias?): Color = when (b) {
    Bias.STRONG_BULL, Bias.BULL -> C.Up
    Bias.STRONG_BEAR, Bias.BEAR -> C.Down
    Bias.NEUTRAL -> C.Gold
    null -> C.Dim
}
