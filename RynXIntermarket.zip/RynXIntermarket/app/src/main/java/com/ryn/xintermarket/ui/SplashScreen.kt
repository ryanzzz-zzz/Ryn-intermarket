package com.ryn.xintermarket.ui

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.*
import androidx.compose.animation.fadeIn
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlin.math.sin

private val steps = listOf(
    "Scanning Macro Environment...",
    "Analyzing US Economic Calendar...",
    "Analyzing USD Strength...",
    "Analyzing Treasury Yields...",
    "Comparing Historical Data...",
    "Building XAUUSD Macro Bias..."
)
private val tickers = listOf("XAUUSD", "DXY", "US10Y")

@Composable
fun SplashScreen(onFinish: () -> Unit) {
    var step by remember { mutableIntStateOf(0) }
    var tick by remember { mutableIntStateOf(0) }
    var showSub by remember { mutableStateOf(false) }
    val progress = remember { Animatable(0f) }
    val title = remember { Animatable(0f) }
    val inf = rememberInfiniteTransition(label = "grid")
    val shift by inf.animateFloat(
        0f, 48f, infiniteRepeatable(tween(5000, easing = LinearEasing)), label = "shift"
    )

    LaunchedEffect(Unit) {
        launch { title.animateTo(1f, tween(900)) }
        launch { delay(900); showSub = true }
        launch { progress.animateTo(1f, tween(5000, easing = LinearOutSlowInEasing)) }
        launch { while (true) { delay(700); tick++ } }
        for (i in steps.indices) { step = i; delay(800) }
        delay(500)
        onFinish()
    }

    Box(Modifier.fillMaxSize().background(C.Bg)) {
        Canvas(Modifier.fillMaxSize()) {
            val gap = 48f
            var x = -gap + shift
            while (x < size.width) {
                drawLine(C.Line, Offset(x, 0f), Offset(x, size.height), 1f); x += gap
            }
            var y = -gap + shift
            while (y < size.height) {
                drawLine(C.Line, Offset(0f, y), Offset(size.width, y), 1f); y += gap
            }
            // Dekoratif saja: garis animasi, BUKAN data pasar.
            val n = 120
            val last = (n * progress.value).toInt()
            val path = Path()
            for (i in 0..last) {
                val px = size.width * i / n
                val py = size.height * 0.72f - i * 1.6f - 28f * sin(i * 0.22f) - 14f * sin(i * 0.61f)
                if (i == 0) path.moveTo(px, py) else path.lineTo(px, py)
            }
            drawPath(path, C.Gold, style = Stroke(width = 3f))
        }
        Column(
            Modifier.align(Alignment.Center),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text(
                "RYN X",
                color = C.Gold,
                fontFamily = FontFamily.Monospace,
                fontWeight = FontWeight.Bold,
                fontSize = 46.sp,
                letterSpacing = 8.sp,
                modifier = Modifier.graphicsAlpha(title.value)
            )
            AnimatedVisibility(showSub, enter = fadeIn(tween(700))) {
                Text(
                    "INTERMARKET",
                    color = C.Text,
                    fontFamily = FontFamily.Monospace,
                    fontSize = 18.sp,
                    letterSpacing = 6.sp
                )
            }
        }
        Column(
            Modifier.align(Alignment.BottomCenter).navigationBarsPadding().padding(28.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text(
                "${tickers[tick % tickers.size]}  linking...",
                style = T.Label
            )
            Spacer(Modifier.height(10.dp))
            Text(steps[step], style = T.Body)
            Spacer(Modifier.height(14.dp))
            Box(Modifier.fillMaxWidth().height(3.dp).background(C.Line)) {
                Box(Modifier.fillMaxWidth(progress.value).fillMaxHeight().background(C.Gold))
            }
        }
    }
}

private fun Modifier.graphicsAlpha(a: Float) = this.then(
    Modifier.graphicsLayerAlpha(a)
)

private fun Modifier.graphicsLayerAlpha(a: Float) =
    androidx.compose.ui.draw.alpha(a)
