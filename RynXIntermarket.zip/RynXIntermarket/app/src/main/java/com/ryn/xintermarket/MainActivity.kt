package com.ryn.xintermarket

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.animation.Crossfade
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import com.ryn.xintermarket.data.*
import com.ryn.xintermarket.engine.Backtest
import com.ryn.xintermarket.engine.Scoring
import com.ryn.xintermarket.ui.*

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            var showSplash by remember { mutableStateOf(true) }
            Crossfade(targetState = showSplash, animationSpec = tween(600), label = "root") { splash ->
                if (splash) SplashScreen { showSplash = false } else Shell()
            }
        }
    }
}

@Composable
private fun Shell() {
    val ctx = LocalContext.current
    var tab by remember { mutableIntStateOf(0) }
    var local by remember { mutableStateOf(false) }
    var reload by remember { mutableIntStateOf(0) }
    var macro by remember { mutableStateOf<MacroState>(MacroState.Loading) }
    var cal by remember { mutableStateOf<CalendarState>(CalendarState.Loading) }

    LaunchedEffect(reload) {
        Status.lastCheck = java.text.SimpleDateFormat("HH:mm:ss", java.util.Locale.US).format(java.util.Date())
        macro = MacroState.Loading; cal = CalendarState.Loading
        macro = MacroRepository.load(ctx)
        cal = CalendarRepository.load()
    }
    // Catat prediksi harian dan nilai prediksi lama (hanya dari data segar).
    LaunchedEffect(macro) {
        val r = macro as? MacroState.Ready ?: return@LaunchedEffect
        if (r.cached) return@LaunchedEffect
        r.data.forEach { (h, m) -> Backtest.record(ctx, h, Scoring.analyze(Scoring.factors(m, h)), m.goldPrice) }
        Backtest.resolve(ctx, r.data[Horizon.TODAY]?.goldPrice)
    }

    val tabs = listOf("Home", "Calendar", "Macro", "History", "Accuracy")
    Column(Modifier.fillMaxSize().background(C.Bg)) {
        Box(Modifier.weight(1f)) {
            when (tab) {
                0 -> Dashboard(macro, cal, local, { local = !local }, { reload++ })
                1 -> CalendarScreen(cal) { reload++ }
                2 -> MacroScreen(macro, cal) { reload++ }
                3 -> HistoryScreen()
                else -> AccuracyScreen()
            }
        }
        Row(Modifier.fillMaxWidth().background(C.Panel).border(1.dp, C.Line).navigationBarsPadding()) {
            tabs.forEachIndexed { i, name ->
                Box(
                    Modifier.weight(1f).clickable { tab = i }.padding(vertical = 14.dp),
                    contentAlignment = Alignment.Center
                ) { Text(name, style = T.Label.copy(color = if (tab == i) C.Gold else C.Dim)) }
            }
        }
    }
}
