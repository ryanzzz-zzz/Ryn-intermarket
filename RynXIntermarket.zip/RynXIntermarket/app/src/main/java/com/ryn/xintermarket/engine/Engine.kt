package com.ryn.xintermarket.engine

import com.ryn.xintermarket.data.*
import java.util.Locale
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt

private fun cl(x: Double) = max(-1.0, min(1.0, x))

enum class Bias(val label: String) {
    STRONG_BULL("STRONG BULLISH"), BULL("BULLISH"), NEUTRAL("NEUTRAL"),
    BEAR("BEARISH"), STRONG_BEAR("STRONG BEARISH")
}

/** signal: -1..+1 (positif = mendukung Gold). points = signal * max. */
data class Factor(val name: String, val max: Int, val signal: Double?, val note: String) {
    val points: Double? get() = signal?.let { it * max }
}

data class Analysis(
    val factors: List<Factor>, val score: Double?, val bias: Bias?,
    val pBull: Double, val pBear: Double, val pNeutral: Double,
    val confidence: Int?, val agreement: String, val coverage: Int,
    val reasons: List<String>, val invalidation: List<String>
)

object Scoring {
    private fun mk(name: String, max: Int, v: Double?, scale: Double, sign: Int,
                   label: String, unit: String, good: String, bad: String): Factor {
        if (v == null) return Factor(name, max, null, "$label: DATA UNAVAILABLE")
        val s = cl(sign * v / scale)
        return Factor(name, max, s, "$label ${String.format(Locale.US, "%+.2f", v)}$unit -> ${if (s >= 0) good else bad}")
    }

    /** Bobot sesuai spesifikasi: USD 30, Yield 20, Fed 20, Inflasi 15, Tenaga kerja 15, Risk 10, Historis 10. */
    fun factors(m: Macro, h: Horizon, history: Double? = null): List<Factor> {
        val sd = when (h) { Horizon.TODAY -> 0.5; Horizon.WEEK -> 1.0; Horizon.MONTH -> 2.0 }
        val sy = when (h) { Horizon.TODAY -> 8.0; Horizon.WEEK -> 15.0; Horizon.MONTH -> 30.0 }
        val real = m.realYieldChgBp != null
        val fedLean = if (m.fedCut != null && m.fedHike != null) m.fedCut - m.fedHike else null
        return listOf(
            mk("USD strength", 30, m.dxyChgPct, sd, -1, "USD index", "%", "softer USD, supportive for Gold", "firmer USD, negative for Gold"),
            mk("Yield", 20, m.realYieldChgBp ?: m.us10yChgBp, sy, -1, if (real) "Real yield" else "US10Y", " bp",
                "lower yield, supportive for Gold", "higher yield, negative for Gold"),
            mk("Fed expectation", 20, fedLean, 50.0, 1, "Cut minus hike probability", " pp",
                "easing priced in, supportive", "tightening priced in, negative"),
            mk("Inflation", 15, m.inflTrendPp, 0.5, -1, "Inflation trend (3m)", " pp",
                "easing, dovish-leaning", "rising, hawkish-leaning"),
            mk("Labor market", 15, m.unempChgPp, 0.3, 1, "Unemployment change", " pp",
                "weakening labor, dovish-leaning", "strong labor, hawkish-leaning"),
            mk("Risk sentiment", 10, m.vixChgPct, 20.0, 1, "VIX change", "%",
                "risk-off, supportive", "risk-on, negative"),
            if (history == null) Factor("Historical setup", 10, null, "Historical setup: needs Phase 5 history data")
            else Factor("Historical setup", 10, cl(history), "Historical setup signal ${String.format(Locale.US, "%+.2f", history)}")
        )
    }

    fun analyze(fs: List<Factor>): Analysis {
        val avail = fs.filter { it.signal != null }
        val availMax = avail.sumOf { it.max }
        val totalMax = fs.sumOf { it.max }
        val cov = (100.0 * availMax / totalMax).roundToInt()
        if (availMax * 2 < totalMax) return Analysis(
            fs, null, null, 0.0, 0.0, 0.0, null, "n/a", cov,
            listOf("Insufficient data: only $cov% of scoring inputs are available (minimum 50%)."), emptyList()
        )
        val score = avail.sumOf { it.points!! } / availMax * 100.0   // skala -100..+100
        val bias = when {
            score >= 60 -> Bias.STRONG_BULL; score >= 25 -> Bias.BULL
            score > -25 -> Bias.NEUTRAL; score > -60 -> Bias.BEAR; else -> Bias.STRONG_BEAR
        }
        val s = cl(score / 100.0)
        val pN = 0.5 * (1 - abs(s)) * (1 - abs(s)) + 0.05
        val rest = 1 - pN
        val pBull = rest * (1 + s) / 2
        val pBear = rest * (1 - s) / 2
        val active = avail.filter { abs(it.signal!!) > 0.1 }
        val same = active.count { (it.signal!! > 0) == (score > 0) }
        val agr = if (active.isEmpty()) 0.0 else same.toDouble() / active.size
        val conf = min(95, (100 * (0.5 * cov / 100.0 + 0.5 * agr)).roundToInt())
        val reasons = active.sortedByDescending { abs(it.points!!) }.map { it.note }
        val inv = when {
            score > 0 -> listOf("USD index rebounds and real yields rise.", "Fed cut odds fall or Fed tone turns hawkish.", "Inflation or labor data surprise strongly to the upside.")
            score < 0 -> listOf("USD index weakens and real yields fall.", "Fed cut odds rise or Fed tone turns dovish.", "Inflation or labor data disappoint materially.")
            else -> listOf("Several factors line up in one direction.")
        }
        return Analysis(fs, score, bias, pBull, pBear, pN, conf, "$same/${active.size}", cov, reasons, inv)
    }
}

object Regime {
    fun detect(m: Macro?): List<String> {
        if (m == null) return emptyList()
        val out = mutableListOf<String>()
        if (m.fedCut != null && m.fedHike != null) {
            val l = m.fedCut - m.fedHike
            if (l > 20) { out.add("Dovish Fed expectations") } else if (l < -20) { out.add("Hawkish Fed expectations") }
        }
        m.vixChgPct?.let { v ->
            if (v > 10) { out.add("Risk-Off") } else if (v < -10) { out.add("Risk-On") }
        }
        m.inflTrendPp?.let { v ->
            if (v > 0.2) { out.add("Inflationary pressure rising") } else if (v < -0.2) { out.add("Easing inflation pressure") }
        }
        m.unempChgPp?.let { v ->
            if (v > 0.2) { out.add("Growth slowdown (labor weakening)") }
        }
        if (m.unempChgPp != null && m.inflTrendPp != null && m.unempChgPp > 0.2 && m.inflTrendPp > 0.2) out.add("Stagflation risk")
        return out
    }
}

enum class Surp(val label: String) { POS("Positive surprise"), NEG("Negative surprise"), INLINE("In-line") }

object Surprise {
    fun num(s: String?): Double? = s?.filter { it.isDigit() || it == '.' || it == '-' }?.toDoubleOrNull()

    fun of(actual: String?, forecast: String?): Surp? {
        val a = num(actual) ?: return null
        val f = num(forecast) ?: return null
        val tol = abs(f) * 0.01
        return when { abs(a - f) <= tol -> Surp.INLINE; a > f -> Surp.POS; else -> Surp.NEG }
    }

    /** +1 = USD bullish, -1 = USD bearish. Data seperti unemployment/claims dibalik. */
    fun usdDir(name: String, s: Surp): Int {
        if (s == Surp.INLINE) return 0
        val inverse = name.contains("unemploy", true) || name.contains("jobless", true) || name.contains("claims", true)
        val d = if (s == Surp.POS) 1 else -1
        return if (inverse) -d else d
    }

    fun effect(dir: Int) = when (dir) {
        1 -> "USD bullish / US10Y bullish / Gold bearish"
        -1 -> "USD bearish / US10Y bearish / Gold bullish"
        else -> "Little change expected (data in line)"
    }
}

data class Confl(val label: String, val detail: String)

object Confluence {
    fun of(events: List<UsEvent>, fedLean: Double?): Confl? {
        val dirs = events.mapNotNull { e -> Surprise.of(e.actual, e.forecast)?.let { Surprise.usdDir(e.name, it) } }.toMutableList()
        if (fedLean != null) {
            if (fedLean > 20) { dirs.add(-1) } else if (fedLean < -20) { dirs.add(1) }
        }
        val nz = dirs.filter { it != 0 }
        if (dirs.size < 3 || nz.isEmpty()) return null
        val pos = nz.count { it > 0 }; val neg = nz.count { it < 0 }
        val d = "${nz.size} directional signals: $pos USD-bullish, $neg USD-bearish."
        return when {
            neg == 0 -> Confl("MACRO CONFLUENCE: Bearish Gold", d)
            pos == 0 -> Confl("MACRO CONFLUENCE: Bullish Gold", d)
            else -> Confl("MACRO CONFLICT: Mixed / Neutral", d)
        }
    }
}

data class Scen(val label: String, val dir: Int)

object Scenarios {
    val list = listOf(
        Scen("NFP beats forecast by +50K", 1), Scen("NFP misses forecast by -50K", -1),
        Scen("CPI above forecast by +0.2pp", 1), Scen("CPI below forecast by -0.2pp", -1)
    )
    const val CAVEAT = "Typical direction only. The actual reaction can differ with positioning and what the market had already priced in."
}

object NewsOutlook {
    /** signals: -1 (data melemah) .. +1 (data menguat). Minimal 3 indikator. */
    fun probs(signals: List<Double>?): Triple<Double, Double, Double>? {
        if (signals == null || signals.size < 3) return null
        val s = cl(signals.average())
        return Triple(0.25 + 0.15 * s, 0.50, 0.25 - 0.15 * s)  // above, near, below
    }
}

object HistoryStats {
    /** (jumlah rilis dengan forecast+actual, jumlah miss). Null jika sampel < 5. */
    fun missRate(r: List<HistRec>): Pair<Int, Int>? {
        val s = r.mapNotNull { Surprise.of(it.actual, it.forecast) }
        if (s.size < 5) return null
        return s.size to s.count { it == Surp.NEG }
    }
}
