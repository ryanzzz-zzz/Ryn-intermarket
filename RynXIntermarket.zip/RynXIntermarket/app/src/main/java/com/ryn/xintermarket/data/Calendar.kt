package com.ryn.xintermarket.data

import com.ryn.xintermarket.BuildConfig
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONArray
import java.net.HttpURLConnection
import java.net.URL

data class UsEvent(
    val name: String,
    val dateTimeNy: String?,
    val previous: String?,
    val forecast: String?,
    val actual: String?,
    val usdEffect: String?,
    val goldEffect: String?,
    val source: String?,
    val updated: String?
)

sealed interface CalendarState {
    data object Loading : CalendarState
    data class Unavailable(val reason: String) : CalendarState
    data class Ready(val events: List<UsEvent>) : CalendarState
}

/** Contoh bentuk data untuk melihat layout. BUKAN data pasar. */
val sampleEvent = UsEvent(
    name = "SAMPLE EVENT (layout preview)",
    dateTimeNy = "sample", previous = null, forecast = null, actual = null,
    usdEffect = null, goldEffect = null, source = "sample", updated = null
)

object CalendarRepository {
    /**
     * Mengambil GET {API_BASE_URL}/calendar. Format JSON: lihat README_PHASE2.md.
     * Hanya event country=US dan impact=high yang ditampilkan.
     */
    suspend fun load(): CalendarState = withContext(Dispatchers.IO) {
        val base = BuildConfig.API_BASE_URL.trim().trimEnd('/')
        if (base.isEmpty()) return@withContext CalendarState.Unavailable(
            "Backend belum dihubungkan. Isi API_BASE_URL di app/build.gradle.kts."
        )
        try {
            val c = URL("$base/calendar").openConnection() as HttpURLConnection
            c.connectTimeout = 10000; c.readTimeout = 10000
            if (c.responseCode != 200) return@withContext CalendarState.Unavailable("Server membalas kode ${c.responseCode}.")
            val arr = JSONArray(c.inputStream.bufferedReader().readText())
            val list = (0 until arr.length()).map { arr.getJSONObject(it) }
                .filter { it.optString("country") == "US" && it.optString("impact").equals("high", true) }
                .map {
                    fun s(k: String) = if (it.isNull(k)) null else it.optString(k).ifBlank { null }
                    UsEvent(s("event") ?: "?", s("datetime_ny"), s("previous"), s("forecast"), s("actual"),
                        s("usd_effect"), s("gold_effect"), s("source"), s("last_updated"))
                }
                .sortedBy { it.dateTimeNy ?: "" }
            if (list.isEmpty()) CalendarState.Unavailable("Tidak ada event high-impact US dari server.")
            else CalendarState.Ready(list)
        } catch (e: Exception) {
            CalendarState.Unavailable("Gagal mengambil data: ${e.javaClass.simpleName}.")
        }
    }
}
