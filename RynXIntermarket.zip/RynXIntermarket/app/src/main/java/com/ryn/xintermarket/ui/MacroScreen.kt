package com.ryn.xintermarket.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.ryn.xintermarket.data.*
import com.ryn.xintermarket.engine.*
import kotlin.math.abs

private const val NA = "DATA UNAVAILABLE"

@Composable
fun MacroScreen(macro: MacroState, cal: CalendarState, onRetry: () -> Unit) {
    var hi by remember { mutableIntStateOf(1) }
    var si by remember { mutableIntStateOf(0) }
    LazyColumn(
        Modifier.fillMaxSize().background(C.Bg).statusBarsPadding(),
        contentPadding = PaddingValues(14.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item { Text("MACRO & INTERMARKET", style = T.Title) }
        if (macro !is MacroState.Ready) {
            item { if (macro is MacroState.Unavailable) Unavail(macro.reason, onRetry) else Text("Loading...", style = T.Body) }
            return@LazyColumn
        }
        val hz = Horizon.values()
        val h = hz[hi]
        val m = macro.data[h]
        val an = hz.associateWith { x -> macro.data[x]?.let { Scoring.analyze(Scoring.factors(it, x)) } }
        val week = macro.data[Horizon.WEEK] ?: macro.data.values.first()
        val events = (cal as? CalendarState.Ready)?.events.orEmpty()

        item { Chips(hz.map { it.label }, hi) { hi = it } }
        item {
            Panel("Intermarket scoring (${h.label})") {
                val a = an[h]
                if (a == null) Text(NA, style = T.Label) else {
                    a.factors.forEach {
                        KV(it.name, if (it.points == null) NA else "${Fmt.n1(it.points!!)} / ${it.max}",
                            when { it.signal == null -> C.Dim; it.signal!! > 0 -> C.Up; it.signal!! < 0 -> C.Down; else -> C.Text })
                    }
                    Spacer(Modifier.height(6.dp))
                    KV("Total (normalized)", a.score?.let { Fmt.n1(it) } ?: "Insufficient data")
                    Text("Bands: +60 strong bullish, +25 bullish, -24..+24 neutral, -25 bearish, -60 strong bearish. Weights are not yet calibrated by backtesting.", style = T.Label)
                }
            }
        }
        item {
            Panel("Micro layer (${h.label} changes)") {
                KV("USD index", m?.dxyChgPct?.let { Fmt.n1(it) + "%" } ?: NA)
                KV("US10Y", m?.us10yChgBp?.let { Fmt.n1(it) + " bp" } ?: NA)
                KV("Real yield", m?.realYieldChgBp?.let { Fmt.n1(it) + " bp" } ?: NA)
                KV("Gold price trend / volatility", NA, C.Dim)
            }
        }
        item {
            Panel("Fed watch") {
                KV("Current Fed funds (upper)", week.fedRate?.let { "$it%" } ?: NA)
                KV("Cut probability", week.fedCut?.let { "$it%" } ?: NA)
                KV("Hold probability", week.fedHold?.let { "$it%" } ?: NA)
                KV("Hike probability", week.fedHike?.let { "$it%" } ?: NA)
                KV("Next FOMC", week.nextFomc ?: NA)
                KV("Previous FOMC", week.prevFomc ?: NA)
                if (week.fedCut != null && week.fedHike != null) {
                    val l = week.fedCut - week.fedHike
                    Spacer(Modifier.height(6.dp))
                    Text(if (l > 20) "Markets price a higher chance of easing. That tends to lower expected real yields, a supportive backdrop for Gold."
                    else if (l < -20) "Markets price a higher chance of tightening. That tends to lift real yields, a headwind for Gold."
                    else "Fed pricing is balanced, so it adds little directional edge.", style = T.Label)
                } else Text("Fed probabilities need a licensed source such as CME FedWatch.", style = T.Label)
            }
        }
        item {
            val r = Regime.detect(week)
            Panel("Regime") { if (r.isEmpty()) Text("Insufficient data", style = T.Label) else r.forEach { Text(it, style = T.Body) } }
        }
        item {
            val c = Confluence.of(events, if (week.fedCut != null && week.fedHike != null) week.fedCut - week.fedHike else null)
            Panel("News confluence") {
                if (c == null) Text("Needs at least 3 released events with forecast and actual.", style = T.Label)
                else { Text(c.label, style = T.Body); Text(c.detail, style = T.Label) }
            }
        }
        item {
            Panel("AI news outlook (next release)") {
                val p = NewsOutlook.probs(week.nfpSignals)
                if (p == null) Text("Insufficient data: needs at least 3 leading indicators (ADP, claims, JOLTS, ISM employment).", style = T.Label)
                else {
                    ProbBar("Above", p.first.toFloat(), C.Up); ProbBar("Near", p.second.toFloat(), C.Gold); ProbBar("Below", p.third.toFloat(), C.Down)
                    Text("Heuristic from average leading-indicator signal. Not a guarantee.", style = T.Label)
                }
            }
        }
        item {
            Panel("What if?") {
                Chips(listOf("NFP +50K", "NFP -50K", "CPI +0.2", "CPI -0.2"), si) { si = it }
                Spacer(Modifier.height(8.dp))
                val s = Scenarios.list[si]
                Text(s.label, style = T.Body)
                Text(Surprise.effect(s.dir), style = T.Body.copy(color = if (s.dir < 0) C.Up else C.Down))
                Spacer(Modifier.height(4.dp))
                Text(Scenarios.CAVEAT, style = T.Label)
            }
        }
        items(hz.toList()) { x ->
            val a = an[x]
            Panel("${x.label} report") {
                if (a?.bias == null) Text("Insufficient data: ${a?.reasons?.firstOrNull() ?: NA}", style = T.Label)
                else {
                    Text("${a.bias.label}  ${Fmt.pct(if (a.score!! >= 0) a.pBull else a.pBear)} (confidence ${a.confidence}%)", style = T.Body.copy(color = biasColor(a.bias)))
                    val by = a.factors.filter { it.points != null }.sortedByDescending { abs(it.points!!) }
                    by.getOrNull(0)?.let { KV("Main driver", it.name) }
                    by.getOrNull(1)?.let { KV("Secondary driver", it.name) }
                    Spacer(Modifier.height(6.dp))
                    Text("Invalidation:", style = T.Body)
                    a.invalidation.forEach { Text("- $it", style = T.Label) }
                }
            }
        }
    }
}
