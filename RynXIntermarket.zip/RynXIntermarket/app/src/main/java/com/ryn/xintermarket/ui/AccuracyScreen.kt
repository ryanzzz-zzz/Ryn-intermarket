package com.ryn.xintermarket.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import com.ryn.xintermarket.data.Horizon
import com.ryn.xintermarket.engine.Backtest

@Composable
fun AccuracyScreen() {
    val ctx = LocalContext.current
    LazyColumn(
        Modifier.fillMaxSize().background(C.Bg).statusBarsPadding(),
        contentPadding = PaddingValues(14.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item { Text("AI HISTORICAL ACCURACY", style = T.Title) }
        item {
            Panel("Prediction track record") {
                Horizon.values().forEach { h ->
                    val (n, ok, pending) = Backtest.stats(ctx, h)
                    val txt = if (n < Backtest.MIN_SAMPLE) "Insufficient data ($n/${Backtest.MIN_SAMPLE} resolved)"
                    else "${ok * 100 / n}% ($ok/$n)"
                    KV("${h.label} accuracy", txt)
                    if (pending > 0) KV("  pending", "$pending")
                }
                KV("News prediction accuracy", "Not tracked yet")
            }
        }
        item {
            Panel("How this works") {
                Text("Each day the app stores its bias per horizon with the Gold price at that moment. When the horizon has passed and a Gold price is available, the call is marked correct or wrong. No accuracy is shown before 30 resolved calls.", style = T.Label)
                Spacer(Modifier.height(6.dp))
                Text("This needs the backend to send gold_price. Without it, predictions stay pending.", style = T.Label)
            }
        }
    }
}
