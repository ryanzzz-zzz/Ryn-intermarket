package com.ryn.xintermarket.engine

import android.content.Context
import com.ryn.xintermarket.data.Horizon
import org.json.JSONArray
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.TimeZone

data class Rec(val id: String, val h: String, val ts: Long, val bias: String, val dir: Int,
               val conf: Int, val gold: Double?, val ok: Boolean?)

object Backtest {
    const val MIN_SAMPLE = 30
    private fun p(c: Context) = c.getSharedPreferences("backtest", 0)

    fun load(c: Context): List<Rec> {
        val a = JSONArray(p(c).getString("recs", "[]"))
        return (0 until a.length()).map { a.getJSONObject(it) }.map {
            Rec(it.getString("id"), it.getString("h"), it.getLong("ts"), it.getString("bias"), it.getInt("dir"),
                it.getInt("conf"), if (it.isNull("gold")) null else it.getDouble("gold"),
                if (it.isNull("ok")) null else it.getBoolean("ok"))
        }
    }

    private fun save(c: Context, l: List<Rec>) {
        val a = JSONArray()
        l.takeLast(500).forEach {
            a.put(JSONObject().put("id", it.id).put("h", it.h).put("ts", it.ts).put("bias", it.bias)
                .put("dir", it.dir).put("conf", it.conf)
                .put("gold", it.gold ?: JSONObject.NULL).put("ok", it.ok ?: JSONObject.NULL))
        }
        p(c).edit().putString("recs", a.toString()).apply()
    }

    fun record(c: Context, h: Horizon, a: Analysis, gold: Double?) {
        val b = a.bias ?: return
        val day = SimpleDateFormat("yyyy-MM-dd", Locale.US).apply { timeZone = TimeZone.getTimeZone("UTC") }.format(Date())
        val id = "$day|${h.key}"
        val l = load(c)
        if (l.any { it.id == id }) return
        val dir = if (a.score!! >= 25) 1 else if (a.score <= -25) -1 else 0
        save(c, l + Rec(id, h.key, System.currentTimeMillis(), b.label, dir, a.confidence ?: 0, gold, null))
    }

    /** Menilai prediksi lama jika harga Gold awal dan harga sekarang tersedia. */
    fun resolve(c: Context, goldNow: Double?) {
        if (goldNow == null) return
        val now = System.currentTimeMillis()
        val day = 86_400_000L
        val l = load(c).map { r ->
            val span = when (r.h) { "today" -> day; "week" -> 7 * day; else -> 30 * day }
            if (r.ok != null || r.gold == null || now - r.ts < span) r
            else {
                val chg = (goldNow / r.gold - 1) * 100
                val flat = when (r.h) { "today" -> 0.3; "week" -> 0.6; else -> 1.2 }
                val ok = when (r.dir) { 1 -> chg > 0; -1 -> chg < 0; else -> kotlin.math.abs(chg) < flat }
                r.copy(ok = ok)
            }
        }
        save(c, l)
    }

    /** (terselesaikan, benar, menunggu) */
    fun stats(c: Context, h: Horizon): Triple<Int, Int, Int> {
        val r = load(c).filter { it.h == h.key }
        val done = r.filter { it.ok != null }
        return Triple(done.size, done.count { it.ok == true }, r.size - done.size)
    }
}
