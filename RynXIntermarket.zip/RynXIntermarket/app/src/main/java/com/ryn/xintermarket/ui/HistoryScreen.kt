package com.ryn.xintermarket.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.ryn.xintermarket.data.*
import com.ryn.xintermarket.engine.*

private const val NA = "DATA UNAVAILABLE"

@Composable
fun HistoryScreen() {
    val names = listOf("NFP", "CPI", "PPI", "PCE")
    var i by remember { mutableIntStateOf(0) }
    var recs by remember { mutableStateOf<List<HistRec>?>(null) }
    var loading by remember { mutableStateOf(true) }
    LaunchedEffect(i) { loading = true; recs = HistoryRepository.load(names[i]); loading = false }
    LazyColumn(
        Modifier.fillMaxSize().background(C.Bg).statusBarsPadding(),
        contentPadding = PaddingValues(14.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item { Text("HISTORICAL NEWS DATABASE", style = T.Title) }
        item { Chips(names, i) { i = it } }
        val r = recs
        if (loading) item { Text("Loading...", style = T.Body) }
        else if (r == null) item { Panel("Status") { Text(NA, style = T.Body.copy(color = C.Down)); Text("History endpoint not reachable or backend not connected.", style = T.Label) } }
        else {
            item {
                Panel("Pattern") {
                    val mr = HistoryStats.missRate(r)
                    if (mr == null) Text("Insufficient data: needs at least 5 releases with both forecast and actual.", style = T.Label)
                    else Text("In ${mr.first} comparable releases, actual came in below forecast ${mr.second} times. Past frequency is not a prediction.", style = T.Label)
                }
            }
            items(r) { x ->
                Panel(x.date) {
                    KV("Forecast", x.forecast ?: NA); KV("Previous", x.previous ?: NA); KV("Actual", x.actual ?: NA)
                    KV("Surprise", Surprise.of(x.actual, x.forecast)?.label ?: NA)
                    KV("USD reaction", x.usd ?: NA); KV("Gold reaction", x.gold ?: NA); KV("Yield reaction", x.yld ?: NA)
                }
            }
        }
    }
}
