package com.ryn.xintermarket.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.ryn.xintermarket.data.*

private const val NA = "DATA UNAVAILABLE"

@Composable
fun CalendarScreen(state: CalendarState, onRetry: () -> Unit) {
    var showSample by remember { mutableStateOf(false) }
    LazyColumn(
        Modifier.fillMaxSize().background(C.Bg).statusBarsPadding(),
        contentPadding = PaddingValues(14.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item {
            Text("US ECONOMIC CALENDAR", style = T.Title)
            Text("High-impact US events only · times in New York (ET)", style = T.Label)
        }
        when (val s = state) {
            is CalendarState.Loading -> item { Text("Loading...", style = T.Body) }
            is CalendarState.Unavailable -> {
                item {
                    Box(Modifier.fillMaxWidth().background(C.Panel, RoundedCornerShape(8.dp))
                        .border(1.dp, C.Line, RoundedCornerShape(8.dp)).padding(14.dp)) {
                        Column {
                            Text(NA, style = T.Body.copy(color = C.Down))
                            Spacer(Modifier.height(6.dp))
                            Text(s.reason, style = T.Label)
                            Spacer(Modifier.height(10.dp))
                            Text("Retry", style = T.Body.copy(color = C.Gold),
                                modifier = Modifier.clickable { onRetry() })
                            Spacer(Modifier.height(8.dp))
                            Text(if (showSample) "Hide layout sample" else "Show layout sample",
                                style = T.Label.copy(color = C.Gold),
                                modifier = Modifier.clickable { showSample = !showSample })
                        }
                    }
                }
                if (showSample) item { EventCard(sampleEvent) }
            }
            is CalendarState.Ready -> items(s.events) { EventCard(it) }
        }
        item {
            Text("Data should come from official sources via your backend. Missing values are never filled in.",
                style = T.Label)
        }
    }
}

@Composable
private fun EventCard(e: UsEvent) {
    Column(
        Modifier.fillMaxWidth().background(C.Panel, RoundedCornerShape(8.dp))
            .border(1.dp, C.Line, RoundedCornerShape(8.dp)).padding(14.dp)
    ) {
        Text(e.name, style = T.Body)
        Text("${e.dateTimeNy ?: NA}  ·  impact: high", style = T.Label)
        Spacer(Modifier.height(10.dp))
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            Cell("Previous", e.previous); Cell("Forecast", e.forecast); Cell("Actual", e.actual)
        }
        Spacer(Modifier.height(10.dp))
        com.ryn.xintermarket.engine.Surprise.of(e.actual, e.forecast)?.let {
            Line("Surprise", it.label)
            Line("Typical reaction", com.ryn.xintermarket.engine.Surprise.effect(com.ryn.xintermarket.engine.Surprise.usdDir(e.name, it)))
        }
        Line("USD effect", e.usdEffect)
        Line("Gold effect", e.goldEffect)
        Line("Historical behavior", null, "Phase 5")
        Line("AI interpretation", null, "Phase 6")
        Spacer(Modifier.height(6.dp))
        Text("Source: ${e.source ?: NA} · updated: ${e.updated ?: NA}", style = T.Label)
    }
}

@Composable
private fun Cell(label: String, v: String?) {
    Column {
        Text(label, style = T.Label)
        Text(v ?: "n/a", style = T.Body.copy(color = if (v == null) C.Dim else C.Text))
    }
}

@Composable
private fun Line(label: String, v: String?, later: String? = null) {
    Row(Modifier.fillMaxWidth().padding(vertical = 2.dp), horizontalArrangement = Arrangement.SpaceBetween) {
        Text(label, style = T.Label)
        Text(v ?: later?.let { "Available in $it" } ?: NA, style = T.Label.copy(color = if (v == null) C.Dim else C.Text))
    }
}
