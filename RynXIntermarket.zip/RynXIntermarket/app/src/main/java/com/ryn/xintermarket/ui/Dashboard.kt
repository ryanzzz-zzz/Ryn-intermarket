package com.ryn.xintermarket.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.ryn.xintermarket.data.*
import com.ryn.xintermarket.engine.*
import kotlin.math.abs

private const val NA = "DATA UNAVAILABLE"

@Composable
fun Dashboard(macro: MacroState, cal: CalendarState, local: Boolean, onToggleLocal: () -> Unit, onRetry: () -> Unit) {
    LazyColumn(
        Modifier.fillMaxSize().background(C.Bg).statusBarsPadding(),
        contentPadding = PaddingValues(14.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                Text("RYN X INTERMARKET", style = T.Title)
                Text(if (local) "Time: local" else "Time: New York", style = T.Label.copy(color = C.Gold),
                    modifier = Modifier.clickable { onToggleLocal() })
            }
        }
        when (macro) {
            MacroState.Loading -> item { Text("Loading...", style = T.Body) }
            is MacroState.Unavailable -> item { Unavail(macro.reason, onRetry) }
            is MacroState.Ready -> {
                val an = Horizon.values().associateWith { h -> macro.data[h]?.let { Scoring.analyze(Scoring.factors(it, h)) } }
                val head = an[Horizon.WEEK] ?: an.values.filterNotNull().firstOrNull()
                val m = macro.data[Horizon.WEEK] ?: macro.data.values.first()
                item { BiasCard(head, m, macro.cached, local) }
                item {
                    Panel("Multi-timeframe bias") {
                        Horizon.values().forEach { h ->
                            val a = an[h]
                            Row(Modifier.fillMaxWidth().padding(vertical = 5.dp)) {
                                Text(h.label, style = T.Body, modifier = Modifier.weight(1f))
                                if (a?.bias == null) Text("Insufficient data", style = T.Label)
                                else Text("${a.bias.label}  ${Fmt.pct(if (a.score!! >= 0) a.pBull else a.pBear)}",
                                    style = T.Body.copy(color = biasColor(a.bias)))
                            }
                        }
                    }
                }
                item {
                    val r = Regime.detect(m)
                    Panel("Market regime") {
                        if (r.isEmpty()) Text("Insufficient data for regime detection", style = T.Label)
                        else r.forEach { Text(it, style = T.Body) }
                    }
                }
                item {
                    Panel("Key drivers (+ supports Gold, - hurts Gold)") {
                        val f = head?.factors?.filter { it.signal != null && abs(it.signal) >= 0.1 }.orEmpty()
                        if (f.isEmpty()) Text("No clear driver", style = T.Label)
                        f.forEach { KV(it.name, "${Fmt.n1(it.points!!)} / ${it.max}", if (it.signal!! > 0) C.Up else C.Down) }
                    }
                }
                item { Explain(head) }
            }
        }
        item { NextNews(cal) }
        item { Risk(cal) }
        item {
            Text(
                "This application provides probabilistic macroeconomic analysis for informational and educational purposes only. It does not guarantee future market movements and should not be considered financial advice.",
                style = T.Label, modifier = Modifier.padding(vertical = 8.dp)
            )
        }
    }
}

@Composable
private fun BiasCard(a: Analysis?, m: Macro, cached: Boolean, local: Boolean) {
    Panel("Gold macro bias (this week model)") {
        if (a?.bias == null) {
            Text("INSUFFICIENT DATA", style = T.Big.copy(color = C.Dim))
            Text(a?.reasons?.firstOrNull() ?: NA, style = T.Label)
        } else {
            Row(verticalAlignment = Alignment.Bottom) {
                Text(a.bias.label, style = T.Big.copy(color = biasColor(a.bias), fontSize = 22.sp))
                Spacer(Modifier.width(12.dp))
                Text("${a.confidence}%", style = T.Big.copy(color = C.Gold))
            }
            Text("confidence (uncalibrated until backtest has enough data)", style = T.Label)
            Spacer(Modifier.height(10.dp))
            ProbBar("Bullish", a.pBull.toFloat(), C.Up)
            ProbBar("Bearish", a.pBear.toFloat(), C.Down)
            ProbBar("Neutral", a.pNeutral.toFloat(), C.Dim)
            Spacer(Modifier.height(8.dp))
            KV("Score (-100..+100)", Fmt.n1(a.score!!))
            KV("Data agreement", a.agreement)
            KV("Input coverage", "${a.coverage}%")
            KV("Major driver", a.factors.filter { it.points != null }.maxByOrNull { abs(it.points!!) }?.name ?: NA)
        }
        KV("Last update", Fmt.ny(m.updated, local) + if (cached) " (cached)" else "")
        KV("Source", m.source ?: NA)
    }
}

@Composable
private fun Explain(a: Analysis?) {
    var open by remember { mutableStateOf(false) }
    Panel("AI macro report") {
        Text(if (open) "Hide analysis" else "View analysis", style = T.Body.copy(color = C.Gold),
            modifier = Modifier.clickable { open = !open })
        if (open) {
            Spacer(Modifier.height(8.dp))
            if (a == null) Text(NA, style = T.Label) else {
                Text(if (a.bias == null) "Why no bias:" else "Gold has a ${a.bias.label.lowercase()} macro bias because:", style = T.Body)
                a.reasons.forEachIndexed { i, r -> Text("${i + 1}. $r", style = T.Label) }
                if (a.invalidation.isNotEmpty()) {
                    Spacer(Modifier.height(8.dp))
                    Text("What would invalidate this bias:", style = T.Body)
                    a.invalidation.forEach { Text("- $it", style = T.Label) }
                }
                Spacer(Modifier.height(8.dp))
                Text("Text is generated by rules from the scored factors above. It is not an LLM and not a certainty.", style = T.Label)
            }
        }
    }
}

private fun upcoming(cal: CalendarState): List<UsEvent> =
    (cal as? CalendarState.Ready)?.events.orEmpty().filter { (it.dateTimeNy ?: "").take(10) >= Fmt.todayNy() }

@Composable
private fun NextNews(cal: CalendarState) {
    Panel("Next high-impact news") {
        val e = upcoming(cal).firstOrNull()
        if (e == null) Text(NA, style = T.Body.copy(color = C.Dim))
        else {
            Text(e.name, style = T.Body)
            KV("Date (NY)", e.dateTimeNy ?: NA)
            KV("Forecast", e.forecast ?: NA)
            val o = e.forecast == null
            Text(if (o) "AI outlook needs forecast and leading indicators (see Macro tab)." else "See Macro tab for outlook.", style = T.Label)
        }
    }
}

@Composable
private fun Risk(cal: CalendarState) {
    Panel("Macro risk (rule: events within the next 2 / 7 days)") {
        if (cal !is CalendarState.Ready) Text(NA, style = T.Body.copy(color = C.Dim))
        else {
            val t = Fmt.todayNy()
            val up = upcoming(cal)
            val within2 = up.count { (it.dateTimeNy ?: "").take(10) <= addDays(t, 2) }
            val within7 = up.count { (it.dateTimeNy ?: "").take(10) <= addDays(t, 7) }
            val (lvl, col) = when { within2 > 0 -> "HIGH" to C.Down; within7 > 0 -> "MEDIUM" to C.Gold; else -> "LOW" to C.Up }
            Text(lvl, style = T.Big.copy(color = col))
            Text("$within2 high-impact event(s) in 2 days, $within7 in 7 days", style = T.Label)
        }
    }
}

fun addDays(date: String, n: Int): String {
    val f = java.text.SimpleDateFormat("yyyy-MM-dd", java.util.Locale.US)
    val d = f.parse(date) ?: return date
    return f.format(java.util.Date(d.time + n * 86_400_000L))
}
