package com.ryn.xintermarket.ui

import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.sp

object C {
    val Bg = Color(0xFF07090D)
    val Panel = Color(0xFF0F131A)
    val Line = Color(0xFF1E2530)
    val Gold = Color(0xFFD4A537)
    val Up = Color(0xFF2ECC8F)
    val Down = Color(0xFFE5534B)
    val Text = Color(0xFFE6E9EF)
    val Dim = Color(0xFF7C8696)
}

object T {
    private val mono = FontFamily.Monospace
    val Title = TextStyle(fontFamily = mono, fontWeight = FontWeight.Bold, fontSize = 15.sp, color = C.Gold)
    val Label = TextStyle(fontFamily = mono, fontSize = 11.sp, color = C.Dim)
    val Body = TextStyle(fontFamily = mono, fontSize = 13.sp, color = C.Text)
    val Big = TextStyle(fontFamily = mono, fontWeight = FontWeight.Bold, fontSize = 34.sp, color = C.Text)
}
