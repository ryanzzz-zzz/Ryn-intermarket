# Ryn X Intermarket v0.3.0 - Phase 3 sampai 9

## Alur data
Worker (backend/worker.js, sumber FRED) -> JSON -> aplikasi -> Scoring -> Regime -> Confluence -> Scenario -> Penjelasan -> Bias.

## Endpoint
- /macro     : today/week/month, tiap field boleh null.
- /calendar  : event US high-impact.
- /history?series=NFP|CPI|PPI|PCE

## Deploy backend dari HP (Cloudflare)
1. Daftar di dash.cloudflare.com, daftar API key gratis di fred.stlouisfed.org.
2. Workers & Pages -> Create -> Worker -> Edit code -> tempel backend/worker.js -> Deploy.
3. Settings -> Variables and Secrets -> tambah secret FRED_API_KEY.
4. Salin alamat worker (https://nama.akun.workers.dev) ke app/build.gradle.kts:
   buildConfigField("String", "API_BASE_URL", "\"https://nama.akun.workers.dev\"")
5. Upload ulang project ke GitHub, build APK.

## Yang tidak tersedia dari FRED (tampil DATA UNAVAILABLE / Insufficient data)
Forecast konsensus, probabilitas Fed (CME FedWatch berlisensi), harga Gold, jam rilis, tanggal FOMC.
Backtest baru berjalan setelah backend mengirim gold_price.
