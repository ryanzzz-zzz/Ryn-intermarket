# Phase 2 - US Economic Calendar

Aplikasi memanggil `GET {API_BASE_URL}/calendar` dan mengharapkan JSON array:

[
  {
    "event": "Nonfarm Payrolls",
    "country": "US",
    "impact": "high",
    "datetime_ny": "2026-10-09T08:30:00-04:00",
    "previous": "...", "forecast": "...", "actual": null,
    "usd_effect": null, "gold_effect": null,
    "source": "nama sumber", "last_updated": "2026-10-06T12:00:00Z"
  }
]

- Nilai yang tidak ada: kirim null. App akan menampilkan "n/a" / DATA UNAVAILABLE.
- Hanya country=US dan impact=high yang ditampilkan.
- API key calendar provider disimpan di backend, JANGAN di APK.
- Alamat backend diisi di app/build.gradle.kts pada baris API_BASE_URL (harus https).
