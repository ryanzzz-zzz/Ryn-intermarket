// Cloudflare Worker untuk Ryn X Intermarket (sumber: FRED).
// Secret yang dibutuhkan: FRED_API_KEY (daftar gratis di fred.stlouisfed.org).
// Catatan: DTWEXBGS = indeks USD broad (trade-weighted), BUKAN DXY resmi.
// Forecast, probabilitas Fed, dan harga Gold TIDAK ada di FRED, jadi dikirim null.
const FRED = "https://api.stlouisfed.org/fred";
const json = (o) => new Response(JSON.stringify(o), { headers: { "content-type": "application/json" } });
const nowIso = () => new Date().toISOString().replace(/\.\d+Z$/, "Z");

async function obs(id, key, limit = 40) {
  const r = await fetch(`${FRED}/series/observations?series_id=${id}&api_key=${key}&file_type=json&sort_order=desc&limit=${limit}`);
  const j = await r.json();
  return (j.observations || []).filter((o) => o.value !== ".").map((o) => ({ d: o.date, v: parseFloat(o.value) }));
}
const diff = (a, n) => (a.length > n ? a[0].v - a[n].v : null);
const pct = (a, n) => (a.length > n ? (a[0].v / a[n].v - 1) * 100 : null);
const yoy = (a, i) => (a.length > i + 12 ? (a[i].v / a[i + 12].v - 1) * 100 : null);

async function macro(key) {
  const [usd, y10, ry, vix, un, cpi, fed] = await Promise.all([
    obs("DTWEXBGS", key, 30), obs("DGS10", key, 30), obs("DFII10", key, 30), obs("VIXCLS", key, 30),
    obs("UNRATE", key, 6), obs("CPIAUCSL", key, 20), obs("DFEDTARU", key, 3),
  ]);
  const y0 = yoy(cpi, 0), y3 = yoy(cpi, 3);
  const infl = y0 != null && y3 != null ? y0 - y3 : null;
  const bp = (x) => (x == null ? null : x * 100);
  const one = (n, u) => ({
    dxy_chg_pct: pct(usd, n), us10y_chg_bp: bp(diff(y10, n)), real_yield_chg_bp: bp(diff(ry, n)),
    vix_chg_pct: pct(vix, n), unemployment_chg_pp: diff(un, u), inflation_trend_pp: infl,
    fed_rate: fed[0]?.v ?? null, fed_cut_prob: null, fed_hold_prob: null, fed_hike_prob: null,
    next_fomc: null, prev_fomc: null, gold_price: null, nfp_leading_signals: null,
    source: "FRED", last_updated: nowIso(),
  });
  return { today: one(1, 1), week: one(5, 1), month: one(21, 3), last_updated: nowIso(), source: "FRED" };
}

// Jadwal rilis resmi dari FRED (hanya tanggal; jam dan forecast tidak tersedia).
const RELEASES = [[50, "Employment Situation (NFP, Unemployment)"], [10, "CPI"], [46, "PPI"], [53, "GDP"],
  [9, "Retail Sales"], [54, "Personal Income and Outlays (PCE)"], [192, "JOLTS"], [180, "Jobless Claims"]];

async function calendar(key) {
  const start = new Date().toISOString().slice(0, 10);
  const end = new Date(Date.now() + 31 * 864e5).toISOString().slice(0, 10);
  const out = [];
  await Promise.all(RELEASES.map(async ([id, name]) => {
    const r = await fetch(`${FRED}/release/dates?release_id=${id}&api_key=${key}&file_type=json&include_release_dates_with_no_data=true&sort_order=desc&limit=20`);
    const j = await r.json();
    (j.release_dates || []).filter((x) => x.date >= start && x.date <= end).forEach((x) =>
      out.push({ event: name, country: "US", impact: "high", datetime_ny: x.date, previous: null, forecast: null,
        actual: null, usd_effect: null, gold_effect: null, source: "FRED release calendar", last_updated: nowIso() }));
  }));
  return out.sort((a, b) => a.datetime_ny.localeCompare(b.datetime_ny));
}

const SERIES = { NFP: ["PAYEMS", "diff"], CPI: ["CPIAUCSL", "pct"], PPI: ["PPIFIS", "pct"], PCE: ["PCEPI", "pct"] };
async function history(key, name) {
  const s = SERIES[name];
  if (!s) return [];
  const a = await obs(s[0], key, 14);
  const val = (i) => (s[1] === "diff" ? a[i].v - a[i + 1].v : (a[i].v / a[i + 1].v - 1) * 100);
  const f = (x) => (s[1] === "diff" ? `${Math.round(x)}K` : `${x.toFixed(2)}%`);
  const out = [];
  for (let i = 0; i < a.length - 2; i++)
    out.push({ date: a[i].d, forecast: null, previous: f(val(i + 1)), actual: f(val(i)), usd_reaction: null, gold_reaction: null, yield_reaction: null });
  return out;
}

export default {
  async fetch(req, env) {
    const u = new URL(req.url);
    const key = env.FRED_API_KEY;
    if (!key) return new Response("FRED_API_KEY belum diset", { status: 500 });
    try {
      if (u.pathname === "/macro") return json(await macro(key));
      if (u.pathname === "/calendar") return json(await calendar(key));
      if (u.pathname === "/history") return json(await history(key, u.searchParams.get("series") || "NFP"));
      return new Response("not found", { status: 404 });
    } catch (e) {
      return new Response("upstream error", { status: 502 });
    }
  },
};
